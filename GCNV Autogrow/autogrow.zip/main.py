import base64
import sys
import json
import functions_framework
import math
from google.cloud import netapp_v1

# Percentage of the volume capacity to increase
capacity_to_increase = 20


def calculate_capacity(volume_capacity, total_storage_pool_capacity, used_storage_pool_capacity, percentage):
    
	available_storage_pool_capacity = total_storage_pool_capacity - used_storage_pool_capacity
	increase_capacity = math.ceil(volume_capacity * (percentage / 100))
    
	if increase_capacity > available_storage_pool_capacity:
		total_storage_pool_capacity += math.ceil((increase_capacity - available_storage_pool_capacity) / 1024) * 1024

	volume_capacity += increase_capacity

	return volume_capacity, total_storage_pool_capacity


# Triggered from a message on a Cloud Pub/Sub topic.
@functions_framework.cloud_event
def netapp_volumes_autogrow(cloud_event):

	print ("A NetApp Volumes capacity event has trigger the autogrow function.")
	message = base64.b64decode(cloud_event.data["message"]["data"]).decode()
	json_message = json.loads(message)

	myregion = json_message["incident"]["resource"]["labels"]["location"]
	myvolume = json_message["incident"]["resource"]["labels"]["name"]
	myproject = json_message["incident"]["resource"]["labels"]["project_id"]

	# Create a client to get the volume information
	client = netapp_v1.NetAppClient()
	volume_name = f"projects/{myproject}/locations/{myregion}/volumes/{myvolume}"

	# Initialize request argument(s)
	request = netapp_v1.GetVolumeRequest(
		name = volume_name,
	)

	# Make the request
	response = client.get_volume(request=request)

	# Get the required information from the response
	myservicelevel = response.service_level
	myvolumecapacity = response.capacity_gib
	mystoragepool = response.storage_pool

	# Check whether the storage pool is Premium or Extreme
	if ((myservicelevel==1)or(myservicelevel==2)):

		# Create a client to get the storage pool information
		client = netapp_v1.NetAppClient()
		storagepool_name = f"projects/{myproject}/locations/{myregion}/storagePools/{mystoragepool}"

		# Initialize request argument(s)
		request = netapp_v1.GetStoragePoolRequest(
			name = storagepool_name,
		)

		# Make the request
		response = client.get_storage_pool(request=request)

		# Get the required information from the response
		mystoragepoolname = response.name
		mystoragepooltotalcapacity = response.capacity_gib
		mystoragepoolusedcapacity = response.volume_capacity_gib

		new_volume_capacity, new_storage_pool_capacity = calculate_capacity(myvolumecapacity,mystoragepooltotalcapacity,mystoragepoolusedcapacity,capacity_to_increase)

		print("The capacity of the storage pool ",mystoragepoolname," is ",mystoragepooltotalcapacity," GiB.")

		if (new_storage_pool_capacity != mystoragepooltotalcapacity):
			print("The storage pool will be resize to ", new_storage_pool_capacity, " GiB.")

			# Create a client
			client = netapp_v1.NetAppClient()

			# Initialize request argument(s)
			storage_pool = netapp_v1.StoragePool()
			storage_pool.name = mystoragepoolname
			storage_pool.capacity_gib = new_storage_pool_capacity

			request = netapp_v1.UpdateStoragePoolRequest(
				update_mask = "capacityGib",
				storage_pool=storage_pool,
			)

			# Make the request
			operation = client.update_storage_pool(request=request)

			# print("Waiting for operation to complete...")

			response = operation.result()

			# Handle the response
			# print(response)

		print("The capacity of the volume ", volume_name," is ",myvolumecapacity," GiB.")
		print("The volume will be resize to ", new_volume_capacity, " GiB.")

		# Create a client
		client = netapp_v1.NetAppClient()

		# Initialize request argument(s)
		volume = netapp_v1.Volume()
		volume.name = volume_name
		volume.capacity_gib = new_volume_capacity

		request = netapp_v1.UpdateVolumeRequest(
			update_mask = "capacityGib",
			volume=volume,
		)

		# Make the request
		operation = client.update_volume(request=request)

		# print("Waiting for operation to complete...")

		response = operation.result()

		# Handle the response
		# print(response)

	else:
		print("The autogrow function has been defined to work only with Premium and Extreme Service levels.")
